package android.support.compat;

public final class R {
}
