package android.support.coreui;

public final class R {
}
