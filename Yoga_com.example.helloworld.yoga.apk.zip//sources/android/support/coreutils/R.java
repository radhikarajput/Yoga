package android.support.coreutils;

public final class R {
}
