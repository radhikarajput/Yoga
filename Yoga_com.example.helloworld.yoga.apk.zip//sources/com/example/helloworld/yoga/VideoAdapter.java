package com.example.helloworld.yoga;

import android.content.Context;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

/* compiled from: VideoListView */
class VideoAdapter extends ListView implements AdapterView.OnItemClickListener {
    public VideoAdapter(Context context) {
        super(context);
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
    }
}
