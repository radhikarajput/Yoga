package com.google.android.youtube.player.internal;

import android.os.IBinder;

public interface b extends t {
    IBinder a();

    k a(j jVar);

    void a(boolean z);
}
