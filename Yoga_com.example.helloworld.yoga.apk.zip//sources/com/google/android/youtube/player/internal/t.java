package com.google.android.youtube.player.internal;

import com.google.android.youtube.player.YouTubeInitializationResult;

public interface t {

    public interface a {
        void a();

        void b();
    }

    public interface b {
        void a(YouTubeInitializationResult youTubeInitializationResult);
    }

    void d();

    void e();
}
