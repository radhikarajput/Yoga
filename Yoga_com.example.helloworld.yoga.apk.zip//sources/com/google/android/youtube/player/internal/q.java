package com.google.android.youtube.player.internal;

import android.os.RemoteException;

public final class q extends RuntimeException {
    public q(RemoteException remoteException) {
        super(remoteException);
    }
}
